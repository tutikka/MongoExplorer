java -cp libs/mongo-explorer.jar:libs/mongo-java-driver-2.13.0.jar:libs/gson-2.3.jar com.tt.mongoexplorer.MongoExplorer
